﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokerYT
{
    class DrawCards
    {

        public static void DrawCardOutline(int xcoor, int ycoor)//xcoor = coordenadaX , Ycoor = coordenadaY
        {
            Console.ForegroundColor = ConsoleColor.White;

            int x = xcoor * 12;
            int y = ycoor;

            Console.SetCursorPosition(x, y);
            Console.Write(" __________\n");

            for (int i = 0; i < 10; i++)
            {
                Console.SetCursorPosition(x, y + 1 + i);

                if (i != 9)
                    Console.WriteLine("|          |");//Ejes derechos e izquierdos.
                else
                    Console.WriteLine("|__________|");//Boton del eje de la carta
            }

             static void DrawCardSuitValue(Carta carta, int xcoor, int ycoor) 
            {
                char cardSuit = ' ';
                int x = xcoor * 12;
                int y = ycoor;


                switch (carta.MiValor1)
                {
                    case Carta.SUIT.CORAZON:
                        cardSuit = Encoding.GetEncoding(437).GetChars(new byte[] { 3 })[0];
                        Console.ForegroundColor = ConsoleColor.Red;
                        break;
                    case Carta.SUIT.DIAMANTE:
                        cardSuit = Encoding.GetEncoding(437).GetChars(new byte[] { 4 })[0];
                        Console.ForegroundColor = ConsoleColor.Red;
                        break;
                    case Carta.SUIT.TREBOL:
                        cardSuit = Encoding.GetEncoding(437).GetChars(new byte[] { 5 })[0];
                        Console.ForegroundColor = ConsoleColor.Black;
                        break;
                    case Carta.SUIT.PICAS:
                        cardSuit = Encoding.GetEncoding(437).GetChars(new byte[] { 6 })[0];
                        Console.ForegroundColor = ConsoleColor.Black;
                        break;
                }


                Console.SetCursorPosition(x + 5, y + 5);
                Console.Write(cardSuit);
                Console.SetCursorPosition(x + 4, y + 7);
                Console.Write(carta.MiValor);

            }


        }

        internal static void DrawCardSuitValue(Carta carta, int x, int y)
        {
            throw new NotImplementedException();
        }
    }
}
