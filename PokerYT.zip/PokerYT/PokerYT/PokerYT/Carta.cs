﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static PokerYT.Carta;

namespace PokerYT
{
    class Carta
    {
        public enum SUIT
        {
            CORAZON,
            TREBOL,
            PICAS,
            DIAMANTE
        }

        public enum VALUE
        {
            DOS = 2, TRES, CUATRO, CINCO, SEIS, SIETE,
            OCHO, NUEVE, DIEZ, J, Q, K, A
        }

        public SUIT MiValor1 { get; set; }
        public VALUE MiValor { get; set; }
    }
}