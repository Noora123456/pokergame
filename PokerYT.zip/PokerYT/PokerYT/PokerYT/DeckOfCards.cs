﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokerYT
{
    class DeckOfCards : Carta //Clase cubierta de las cartas.
    {
        const int NUM_DE_CARTAS = 52; //Numero total de cartas.
        private Carta[] deck; //Arreglo de todas las cartas.

        public DeckOfCards()
        {
            deck = new Carta[NUM_DE_CARTAS];
        }

        public Carta[] getDeck { get { return deck; } } 

        
        public void setUpDeck()
        {
            int i = 0;
            foreach(SUIT s in Enum.GetValues(typeof(SUIT)))
            {
                foreach(VALUE v in Enum.GetValues(typeof(VALUE)))
                {
                    deck[i] = new Carta { MiValor1 = s, MiValor = v };
                    i++;
                }
            }

            ShuffleCards();
        }

        public void ShuffleCards()
        {
            Random rand = new Random();
            Carta temp;

            //run the shuffle 1000 times
            for (int shuffleTimes = 0; shuffleTimes < 1000; shuffleTimes++)
            {
                for (int i = 0; i < NUM_DE_CARTAS; i++)
                {
                    //swap the cards
                    int secondCardIndex = rand.Next(13);
                    temp = deck[i];
                    deck[i] = deck[secondCardIndex];
                    deck[secondCardIndex] = temp;
                }
            }
        }
    }
}
