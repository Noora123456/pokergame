﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokerYT
{
    public enum Mano
    {
        Trios,//Tres cartas del mismo valor y dos distintas.,
        Pares,//Dos cartas del mismo palo y tres cartas distintas.


    }

    public struct ValorMano
    {
        public int Total { get; set; }
        public int HighCard { get; set; }
    }

    class HandEvaluator : Carta
    {
        private int CORAZONSum;
        private int DIAMANTESum;
        private int TREBOLSum;
        private int PICASSum;
        private Carta[] carta;
        private ValorMano valormano;

        public HandEvaluator(Carta[] sortedHand)
        {
            CORAZONSum = 0;
            DIAMANTESum = 0;
            TREBOLSum = 0;
            PICASSum = 0;
            carta = new Carta[5];
            Cartas = sortedHand;
            valormano = new ValorMano();
        }

        public ValorMano ValorManos
        {
            get { return valormano; }
            set { valormano = value; }
        }

        public Carta[] Cartas
        {
            get { return carta; }
            set
            {
                carta[0] = value[0];
                carta[1] = value[1];
                carta[2] = value[2];
                carta[3] = value[3];
                carta[4] = value[4];
            }
        }

        public Mano ManoEvaluativa()
        {

            getNumberOfSuit();
            if (Trios()) { 
            return Mano.Trios;
        } else{ if (Pares())
                return Mano.Pares;
            }
        }



        private void getNumberOfSuit()
        {
            foreach (var element in carta)
            {
                if (element.MiValor1 == Carta.SUIT.CORAZON)
                    CORAZONSum++;
                else if (element.MiValor1 == Carta.SUIT.DIAMANTE)
                    DIAMANTESum++;
                else if (element.MiValor1 == Carta.SUIT.TREBOL)
                    TREBOLSum++;
                else if (element.MiValor1 == Carta.SUIT.PICAS)
                    PICASSum++;
            }
        }







        private bool Trios()
        {
      
            if ((carta[0].MiValor == carta[1].MiValor && carta[0].MiValor == carta[2].MiValor) ||
            (carta[1].MiValor == carta[2].MiValor && carta[1].MiValor == carta[3].MiValor))
            {
                valormano.Total = (int)carta[2].MiValor * 3;
               valormano.HighCard = (int)carta[4].MiValor;
                return true;
            }
            else if (carta[2].MiValor == carta[3].MiValor && carta[2].MiValor == carta[4].MiValor)
            {
                valormano.Total = (int)carta[2].MiValor * 3;
               valormano.HighCard = (int)carta[1].MiValor;
                return true;
            }
            return false;
        }

        private bool Pares()
        {

            if (carta[0].MiValor == carta[1].MiValor && carta[2].MiValor == carta[3].MiValor)
            {
               valormano.Total = ((int)carta[1].MiValor * 2) + ((int)carta[3].MiValor * 2);
                valormano.HighCard = (int)carta[4].MiValor;
                return true;
            }
            else if (carta[0].MiValor == carta[1].MiValor && carta[3].MiValor == carta[4].MiValor)
            {
                valormano.Total = ((int)carta[1].MiValor * 2) + ((int)carta[3].MiValor * 2);
               valormano.HighCard = (int)carta[2].MiValor;
                return true;
            }
            else if (carta[1].MiValor == carta[2].MiValor && carta[3].MiValor == carta[4].MiValor)
            {
               valormano.Total = ((int)carta[1].MiValor * 2) + ((int)carta[3].MiValor * 2);
                valormano.HighCard = (int)carta[0].MiValor;
                return true;
            }
            return false;
        }


    }
}
