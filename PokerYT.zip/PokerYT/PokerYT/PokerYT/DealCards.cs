﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokerYT
{
    class DealCards : DeckOfCards
    {
        private Carta[] ManoJugador;
        private Carta[] ManoComputador;
        private Carta[] SorteoJugador;
        private Carta[] SorteoComputador;

        public DealCards()
        {
           ManoJugador = new Carta[5];
            SorteoJugador= new Carta[5];
           ManoComputador = new Carta[5];
            SorteoComputador = new Carta[5];
        }

        public void Deal()
        {
            setUpDeck(); 
            getHand();
            sortCards();
            displayCards();
            evaluateHands();
        }

        public void getHand()
        {
            //5 cartas para el jugador
            for (int i = 0; i < 5; i++)
                ManoJugador[i] = getDeck[i];

            //5 cartas para el computador
            for (int i = 5; i < 10; i++)
              ManoComputador[i - 5] = getDeck[i];
        }

        public void sortCards()
        {
            var queryPlayer = from hand in ManoJugador
                              orderby hand.MiValor
                              select hand;

            var queryComputer = from hand in ManoComputador
                                orderby hand.MiValor
                                select hand;

            var index = 0;
            foreach (var element in queryPlayer.ToList())
            {
                SorteoJugador[index] = element;
                index++;
            }

            index = 0;
            foreach (var element in queryComputer.ToList())
            {
                SorteoComputador[index] = element;
                index++;
            }
        }

        public void displayCards()
        {
            Console.Clear();
            int x = 0; //La posicion x se mueve de derecha a izquierda.
            int y = 1;//La posicion y se mueve de arriba a abajo.

           
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("Mano Jugadora");
            for (int i = 0; i < 5; i++)
            {
                DrawCards.DrawCardOutline(x, y);
                DrawCards.DrawCardSuitValue(SorteoJugador[i], x, y);
                x++;
            }
            y = 15;
            x = 0; 
            Console.SetCursorPosition(x, 14);
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.WriteLine("Mano computador");
            for (int i = 5; i < 10; i++)
            {
                DrawCards.DrawCardOutline(x, y);
                DrawCards.DrawCardSuitValue(SorteoComputador[i - 5], x, y);
                x++;//move to the right
            }

        }
            public void evaluateHands()
            {
                
                HandEvaluator jugadorEvaluador = new HandEvaluator(SorteoJugador);
                HandEvaluator computadorEvaluador = new HandEvaluator(SorteoComputador);

                
              Mano playerHand = jugadorEvaluador.ManoEvaluativa();
                Mano computerHand = computadorEvaluador.ManoEvaluativa();

                
                Console.WriteLine("\n\n\n\n\nMano Jugador: " + playerHand);
                Console.WriteLine("\nMano Computador: " + computerHand);

              
                if (playerHand > computerHand)
                {
                    Console.WriteLine("El jugador gano!");
                }
                else if (playerHand < computerHand)
                {
                    Console.WriteLine("El computador gano.!");
                }
                else 
                {
                   
                    if (jugadorEvaluador.ValorManos.Total > computadorEvaluador.ValorManos.Total)
                        Console.WriteLine("El jugador gano!");
                    else if (jugadorEvaluador.ValorManos.Total < computadorEvaluador.ValorManos.Total)
                        Console.WriteLine("El computador gano!");
                   
                    else if (jugadorEvaluador.ValorManos.HighCard > computadorEvaluador.ValorManos.HighCard)
                        Console.WriteLine("El jugador gano!");
                    else if (jugadorEvaluador.ValorManos.HighCard <computadorEvaluador.ValorManos.HighCard)
                        Console.WriteLine("El computador gano!");
                    else
                        Console.WriteLine("DRAW, no one wins!");
                }
            }
        }
    }
